# Security Policy

We take the security of CampusGPT seriously. This document outlines how to report vulnerabilities and lists supported versions.

## Supported Versions

Only the following versions of CampusGPT receive security updates:

| Version | Supported |
| :--- | :--- |
| 1.2.x | :white_check_mark: Yes |
| 1.1.x | :x: No |
| < 1.1.0 | :x: No |

---

## Reporting a Vulnerability

If you discover a security vulnerability within CampusGPT, please report it privately:

1. **Do not** disclose the vulnerability publicly in Git issues, discussions, or public chats.
2. Send a detailed report to **security@campusgpt.edu** with:
    * Description of the vulnerability.
    * Steps to reproduce the issue (proof-of-concept script, request payloads, or screenshots).
    * Potential impact on the system or host environment.
3. We will acknowledge your report within 48 hours and work on a security fix.
4. Once resolved, we will publish a patch release (e.g. `1.2.1`) and update this changelog.
