# Changelog

All notable changes to the CampusGPT project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [1.2.0] - 2026-06-20
### Added
- Created `AGENTS.md` outlining repository contribution instructions.
- Configured `.editorconfig` to enforce formatting parameters.
- Introduced `SECURITY.md` and `CODE_OF_CONDUCT.md` guidelines.
- Configured production-ready multi-stage `Dockerfile` and `.dockerignore`.
- Created detailed functional specification files in `specs/` (and `.specify/` directory).
- Added `tests/test_chat.py` to check database conversational logs operations.
- Added `tests/test_summarizer.py` verifying document summarizer logic.
- Built a validation script `validate_project.py` checking directory schemas and file footprints.

---

## [1.1.0] - 2026-06-20
### Added
- Integrated static type hinting across core RAG modules (`mypy` compliant).
- Added static quality checkers (`black` formatting, `ruff` linter, and git `pre-commit` hooks).
- Implemented isolated testing database schema redirects under `tests/conftest.py`.
- Wrote unit tests for Document Parser, Embeddings Cache, FAISS Vector Store, and RAG execution pipeline.
- Logged RAG evaluation metrics (retrieval time, generation time, context length, feedback score) into a SQLite audit database log.
- Created `FEATURE_CHECKLIST.md` and `QUALITY_REPORT.md` quality check verification documents.

---

## [1.0.0] - 2026-06-16
### Added
- Initial release of CampusGPT: Streamlit University Knowledge Assistant.
- Integrated `pymupdf4llm` page-by-page markdown extraction.
- Persisted vector database partitions in directory structures.
- Added local GGUF models mapping supporting offline execution using `llama-cpp-python`.
- Added standard semantic keyword search and summarization page views.
