# 🎓 CampusGPT - University Knowledge & Document RAG Assistant

CampusGPT is an advanced Retrieval-Augmented Generation (RAG) assistant designed for university students, faculty, and administrators. It enables users to navigate academic handbooks, syllabi, course guidelines, and policy documents using semantic search and contextual AI chat.

The application features a hybrid AI execution mode, allowing it to run either via cloud-based API models (Google Gemini) or completely offline using local GGUF models.

---

## ✨ Key Features

1. **🔐 Secure Authentication**: Multi-role system (User, Admin) with secure password validation and SQLite user management.
2. **📄 Layout-Aware Document Parsing**: Extracts markdown headers, lists, and tables from academic PDF documents using `pymupdf4llm`.
3. **🧠 Cached Local Embeddings**: Speeds up embeddings generation and search query operations by caching embedding vectors in an SQLite database.
4. **🔍 Advanced Retrieval-Augmented Generation (RAG)**: Integrates semantic search, query thresholds, and top-k matching with citations linking back to page sources.
5. **📴 Hybrid AI Engine**: Switch seamlessly between cloud Gemini API execution and offline GGUF model inferencing.
6. **📝 Document Summarization**: Generates markdown-structured executive summaries, action items, and tables for uploaded documents.
7. **📊 Analytics & Monitoring**: Tracks system usage, latency, query cache hit rates, average document similarity scores, and model execution times.

---

## 📂 Folder Structure

```text
├── .specify/               # Internal compliance tracking marker
├── assets/                 # Application design assets & stylesheets
│   └── styles.css          # Custom Vanilla CSS theme configuration
├── database/               # Directory containing SQLite databases
│   └── campusgpt.db        # Core production database
├── models/                 # Store local GGUF models (e.g., Llama-3, Qwen)
├── modules/                # Core Python logic modules
│   ├── analytics.py        # Analytics metrics reporting and logs retrieval
│   ├── auth.py             # User registration, login, and deletion checks
│   ├── chunking.py         # Text chunking rules and token split limiters
│   ├── database.py         # SQLite connection manager & schema migration
│   ├── document_parser.py  # PDF text extraction and layout processing
│   ├── embedding_manager.py# Vector generation & SQLite embeddings cache
│   ├── llm_local.py        # Local LlamaGGUF generation stream handlers
│   ├── pdf_loader.py       # Helper functions to validate & write local PDFs
│   ├── rag_chain.py        # Prompt styling and LangChain LLM execution
│   ├── rag_pipeline.py     # Main RAG orchestrator with SQLite query cache
│   ├── retriever.py        # Text retrieval algorithms and filtering options
│   └── vector_store.py     # FAISS vector database integration
├── pages/                  # Streamlit routed interface modules
│   ├── 1_Chat.py           # RAG Chat panel with citation list and metrics
│   ├── 2_Upload.py         # Document uploader and background parser
│   ├── 3_Summarize.py      # Summary generator with PDF export function
│   ├── 4_Analytics.py      # Metrics visualizations and performance charts
│   └── 5_Search.py         # Standalone semantic search query panel
├── specs/                  # Architectural and feature specification files
├── tests/                  # Pytest unit and integration test suite
├── app.py                  # Main Streamlit dashboard entrypoint
├── Dockerfile              # Containerization configuration
├── Makefile                # Task runner commands (lint, test, format, etc.)
└── validate_project.py     # Root project compliance validation script
```

---

## ⚙️ Environment Variables

Create a `.env` file in the root directory of the project. A template is provided in `.env.example`:

```ini
# Gemini API Key (Required for Cloud AI Mode)
GEMINI_API_KEY=your_gemini_api_key_here

# Default Admin Bootstrap Credentials (Run on initial startup)
ADMIN_EMAIL=admin@campusgpt.edu
ADMIN_PASSWORD=secure_admin_password
ADMIN_NAME="Administrator"
```

---

## 🚀 Setup & Installation

### Option 1: Local Installation

1. **Clone the Repository**:
   ```bash
   git clone https://github.com/poojareddylankala13/CampusGPT-RAG.git
   cd CampusGPT-RAG
   ```

2. **Set Up virtual Environment**:
   ```bash
   python -m venv .venv
   # On Windows (PowerShell):
   .venv\Scripts\Activate.ps1
   # On Linux/macOS:
   source .venv/bin/activate
   ```

3. **Install Dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

4. **Initialize Environment Variables**:
   Create a `.env` file and populate your `GEMINI_API_KEY`.

5. **Start the Application**:
   ```bash
   streamlit run app.py
   ```

---

### Option 2: Docker Setup (Production-Ready)

To run the application in an isolated container:

1. **Build the Docker Image**:
   ```bash
   docker build -t campusgpt:latest .
   ```

2. **Run the Container**:
   Pass the environment variables file using `--env-file`:
   ```bash
   docker run -d -p 8501:8501 --env-file .env --name campusgpt campusgpt:latest
   ```

3. **Access the App**:
   Open [http://localhost:8501](http://localhost:8501) in your browser.

---

## 🧪 Testing & Validation

### 1. Isolated Unit Testing
The test suite utilizes a temporary SQLite database (`test_campusgpt.db`) so that production registers and logs are never modified.

Run the test suite with code coverage:
```bash
pytest
```
*Or via the task runner:*
```bash
make test
```

### 2. Formatting, Linting & Typing Checks
Ensure all files adhere to the strict pre-commit requirements:
```bash
# Code Formatting (Black)
black .

# Code Linting (Ruff)
ruff check .

# Static Type Checks (Mypy)
mypy .
```
*Or run all compliance commands together:*
```bash
make all
```

### 3. Footprint Validation
Run the validation script to verify that all necessary directory markers, spec files, compliance documents, and test configurations exist:
```bash
python validate_project.py
```
*Or via the task runner:*
```bash
make validate
```
