# AI Agent Guidelines & Contribution Instructions

Welcome! This repository is designed to support pair programming with both human developers and autonomous AI agentic coding assistants. 

To maintain consistency, stability, and clean development style, all agents MUST follow the conventions documented below.

---

## 🤖 Code Style & Integrity Standards

1. **Zero Placeholders**: Never insert comments like `# TODO: implement` or stub/failing functions in source code or test suites. All implementations must be production-ready and fully functional.
2. **Formatting**: Always format Python code with **Black** (`black .`) before committing.
3. **Linting Rules**:
    * Run **Ruff** checks: `ruff check .`
    * Long lines (E501) and whitespace blank lines (W293) are ignored in `ruff.toml` to support multi-line HTML strings used in Streamlit interfaces. All other PEP 8 syntax errors and import rules must pass without warnings.
4. **Static Type Safety**: 
    * Add strict parameter and return type annotations to all logic functions in python core modules under the `modules/` directory.
    * Mypy must pass type checks: `mypy .` (excluding tests, pages, and samples via config).
5. **Preserve Existing Features**: Do not replace or modify existing features (such as user database registrations, local GGUF models mapping, FAISS dimension partitions, or caching mechanics) unless explicitly requested.

---

## 🧪 Testing Guidelines

1. **Isolated Testing Database**:
    * Never run tests against the production SQLite database `database/campusgpt.db` to prevent user accounts and log metrics from being contaminated or deleted.
    * All test suites must use the pytest fixture redirect (`tests/conftest.py`) which points operations to `test_campusgpt.db` and deletes the file after execution.
2. **Mocking Heavy Dependencies**:
    * When writing unit tests for embeddings or local LLM execution, use mock stubs (`unittest.mock.patch`) to simulate model vectors and streaming outputs. Test suites must complete in milliseconds without requiring heavy weight files (GGUFs) to be loaded on standard CPU test environments.
3. **Test Coverage**: Keep overall project coverage high, prioritizing core logic files in the `modules/` folder.

---

## 📦 Containerization & Deployment

1. **Docker Setup**: Ensure changes remain compatible with the project's production-ready `Dockerfile`.
2. **Git Pre-commit Validation**: Set up git pre-commit validation by running `pre-commit install`. Staged files are formatted, linted, and type-checked before commits are processed.
